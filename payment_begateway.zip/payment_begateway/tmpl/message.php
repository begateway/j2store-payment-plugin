<?php
/**
 * @package J2Store
 * @copyright Copyright (c) 2018 begateway.com
 * @license GNU GPL v3 or later
 */
/** ensure this file is being included by a parent file */
defined('_JEXEC') or die('Restricted access');

echo $vars->message;
