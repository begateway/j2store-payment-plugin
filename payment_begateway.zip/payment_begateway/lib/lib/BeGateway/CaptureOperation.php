<?php
namespace BeGateway;

class CaptureOperation extends ChildTransaction {
}
?>
